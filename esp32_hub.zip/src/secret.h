#pragma once
#define WIFI_SSID_BACKUP "Federico's Wifi"
#define WIFI_PASS_BACKUP "F3dericolo"

#define WIFI_SSID_PRIMARY "Specialvideo_Corporate"
#define WIFI_PASS_PRIMARY "selice42"

#define SPOTIFY_CLIENT_ID_VALUE "bf07363fbecd4ad18d3791a5d1ad8366"
#define SPOTIFY_CLIENT_SECRET_VALUE "c4bf6381740d490e9c53c63fdfeb0710"
